############################### Installation script for MSM ##################################
# Author : Jhelum Bisht (jhelum.bisht@lsi.com)
# Date of Creation: 15th Oct 2007 
# Changes: Server only component ("-x" option) for VMWare system
##############################################################################################
#!/bin/sh
echo " "
echo "STOP!  BEFORE YOU INSTALL OR USE THIS SOFTWARE"
echo " "
echo "Carefully read this Software License Agreement. Installing or using this Software indicates that you agree to abide by this Software License Agreement. If you do not agree with it, promptly return the Software and we will refund the purchase price." 
echo " "
echo " "
echo "		Software License Agreement"
echo " "
echo "PLEASE READ CAREFULLY BEFORE STARTING INSTALLATION OF THE SOFTWARE"
echo " "
echo "THE SOFTWARE AND DOCUMENTATION PROVIDED HEREIN IS PROPRIETARY TO AVAGO TECHNOLOGIES AND ITS LICENSORS. AVAGO TECHNOLOGIES IS WILLING TO LICENSE THE SOFTWARE AND DOCUMENTATION TO YOU ONLY UPON THE CONDITION THAT YOU ACCEPT ALL OF THE TERMS CONTAINED IN THIS SOFTWARE LICENSE AGREEMENT. BY USING THIS SOFTWARE, YOU, THE END-USER, AGREE TO THE LICENSE TERMS BELOW. IF YOU DO NOT AGREE TO THESE TERMS, YOU MAY NOT USE THE SOFTWARE." 
echo " "
echo "1. Grant of License" 
echo " "
echo "Conditioned upon compliance with the terms and conditions of this Software License Agreement ("Agreement"), Avago Technologies ("AVAGO") grants you, the original licensee, a nonexclusive and nontransferable limited license to use (including installation on multiple computers) for your internal business purposes the "Software and the Documentation,"Permitted Use""" 
echo " "
echo "2. License Conditions; Confidentiality" 
echo " "
echo "The Software and Documentation are confidential information of AVAGO and its licensors. Except as expressly permitted herein, you may not disclose or give copies of the Software or Documentation to others and you may not let others gain access to the same. You may not post the Software or Documentation, or otherwise make available, in any form, on the Internet or in other public places or media. You may not modify, adapt, translate, rent, lease, loan, distribute or resell for profit, or create derivative works based upon, the Software or Documentation or any part of thereof, but you may transfer the original media containing the Software and Documentation on a one-time basis provided you retain no copies of the Software and Documentation and the recipient assumes all of the terms of this Agreement. You may not reverse engineer, decompile, disassemble or otherwise attempt to derive source code from the Software except to the extent allowed by law." 
echo " "
echo "3. No Warranty" 
echo " "
echo "YOU ACKNOWLEDGE THAT THE SOFTWARE AND DOCUMENTATION ARE LICENSED "AS IS," AND AVAGO MAKES NO REPRESENTATIONS OR WARRANTIES EXPRESS, IMPLIED, STATUTORY OR OTHERWISE REGARDING THE SOFTWARE AND DOCUMENTATION.  ANY IMPLIED WARRANTY OR CONDITION OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, NON-INFRINGEMENT, SATISFACTORY QUALITY, NON-INTERFERENCE, ACCURACY OF INFORMATIONAL CONTENT, OR ARISING FROM A COURSE OF DEALING, LAW, USAGE, OR TRADE PRACTICE, ARE HEREBY EXCLUDED TO THE EXTENT ALLOWED BY APPLICABLE LAW AND ARE EXPRESSLY DISCLAIMED BY AVAGO , ITS SUPPLIERS AND LICENSORS.  TO THE EXTENT AN IMPLIED WARRANTY CANNOT BE EXCLUDED, SUCH WARRANTY IS LIMITED IN DURATION TO A PERIOD OF THIRTY (30) DAYS FROM THE DATE OF RECEIPT BY THE ORIGINAL LICENSEE.  BECAUSE SOME STATES OR JURISDICTIONS DO NOT ALLOW LIMITATIONS ON HOW LONG AN IMPLIED WARRANTY LASTS, THE ABOVE LIMITATION MAY NOT APPLY. THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS, AND YOU MAY ALSO HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION." 
echo " "
echo "4. LIMITATION OF LIABILITY AND REMEDIES" 
echo " "
echo "IN NO EVENT SHALL AVAGO OR ITS LICENSORS BE LIABLE TO YOU FOR ANY INDIRECT, CONSEQUENTIAL, EXEMPLARY, INCIDENTAL OR SPECIAL DAMAGES ARISING FROM THIS AGREEMENT OR THE USE OF THE SOFTWARE OR DOCUMENTATION (INCLUDING, WITHOUT LIMITATION, DAMAGE FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, LOSS OF GOODWILL, OR OTHER PECUNIARY LOSS), WHETHER RESULTING FROM AVAGO NEGLIGENCE OR OTHERWISE, EVEN IF AVAGO WAS ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. AVAGO MAXIMUM LIABILITY FOR ANY DAMAGES ARISING UNDER THIS AGREEMENT AND THE USE OF THE SOFTWARE AND DOCUMENTATION WILL NOT EXCEED AN AMOUNT EQUAL TO THE LICENSE FEES YOU PAID TO AVAGO FOR THE SOFTWARE AND DOCUMENTATION. THE LAWS OF SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF LIABILITY, AND THE ABOVE EXCLUSION MAY NOT APPLY TO YOU." 
echo " "
echo "5. U.S. Government End User Purchasers" 
echo " "
echo "The Software and Documentation qualify as "commercial items," as that term is defined at Federal Acquisition Regulation (.FAR.) (48 C.F.R.) 2.101, consisting of "commercial computer software" and "commercial computer software documentation" as such terms are used in FAR 12.212. Consistent with FAR 12.212 and DoD FAR Supp. 227.7202-1 through 227.7202-4, and notwithstanding any other FAR or other contractual clause to the contrary, you may provide to Government end user or, if this Agreement is direct, Government end user will acquire, the Software and Documentation with only those rights set forth in this Agreement. Use of either the Software or Documentation or both constitutes agreement by the Government that the Software and Documentation are "commercial computer software" and "commercial computer software documentation," and constitutes acceptance of the rights and restrictions herein." 
echo " "
echo "6. Term And Termination" 
echo " "
echo "You may terminate this Agreement at any time, and it will automatically terminate if you fail to comply with it. If terminated, you must immediately destroy the Documentation and the Software and all copies you have made." 
echo " "
echo "7. Audit Rights" 
echo " "
echo "AVAGO shall have the right on reasonable notice, at its own cost and no more than once per year, directly or through its independent auditors, to inspect, examine, take extracts, and make copies from, your records to the extent reasonably necessary to verify your compliance with the terms and conditions of this Agreement. This right shall apply during the term of this Agreement and for one (1) year thereafter." 
echo " "
echo "8. Export" 
echo " "
echo "You may not export this Software or Documentation, unless you have complied with applicable United States and foreign government laws." 
echo " "
echo "9. General" 
echo " "
echo "You assume full responsibility for the legal and responsible use of the Software and Documentation. You agree that this Agreement is the complete agreement between you and AVAGO (and that any verbal or written statements that are not reflected in this Agreement and any prior agreements, are superseded by this Agreement). To be effective, any amendment of this Agreement must be in writing and signed by both you and AVAGO . Should any provisions of this Agreement be held to be unenforceable, then such provision shall be separable from this Agreement and shall not affect the remainder of the Agreement. This Agreement shall be governed by California law, not including its choice of law provisions. The United Nations Convention on the International Sale of Goods shall not be applied to this Agreement. All rights in the Software and Documentation not specifically granted in this Agreement are reserved by AVAGO or its licensors. The English language version of this Agreement shall be the official version. The terms and conditions of this Software License Agreement shall be binding upon you and your respective heirs, successors and assigns." 
echo " "
echo "10. Survival" 
echo " "
echo "The provisions of Sections 2, 3, 4, 7, 8 and 9 shall survive any termination of this Agreement."
	echo " "
	echo " "
	echo " "

	echo -n Press Y to accept the License Agreement : 
	read EULA
	if [ "$EULA" != "y" -a "$EULA" != "Y" ]
	then
		  echo "EULA declined by User. Exiting installation..."
		  exit 1;
	fi

firstArgDone="0"
removepopup="0"
removeSL="0"
removeSLIR="0"
vmware35="0"
vmware40="0"
startup35="0"
startup40="0"

	echo "Select the operating system :"
	echo "enter 1 for VMware 3.5 "
	echo "enter 2 for VMware 4.x " 
	echo "Enter the Operating system:(1 or 2) "
	read OS
	if [ "$OS" = "1" ]
	then
		  echo "Do you want to use the storelib packaged in MSM package ?"
		  echo "enter n if you want to use the inbox storelib"
		  echo "enter y if you want to use the storelib packaged in MSM"
			read SL
		  	if [ "$SL" = "y" -o "$SL" = "Y" ]
			then
		  		vmware35="1"
			else
				startup35="1"
			fi
	fi
	if [ "$OS" = "2" ]
	then
		  echo "Do you want to use the storelib packaged in MSM package ?"
		  echo "enter n if you want to use the inbox storelib"
		  echo "enter y if you want to use the storelib packaged in MSM"
			read SL
		  	if [ "$SL" = "y" -o "$SL" = "Y" ]
			then
		  		vmware40="1"		
			else
				startup40="1"
			fi
	fi

	if [ "$OS" != "1" -a "$OS" != "2" ]
	then
		  echo "Invalid Selection..Exiting installation..."
		  exit 1;
	fi
	

echo -n "Starting Server only installation of MegaRAID Storage Manager 15.03.01-00"
		setuptype="x"
		removepopup="1"
		removeSL="1"
		removeSLIR="1"


echo "...."

export setuptype=$setuptype
export removepopup=$removepopup
export removeSL=$removeSL
export removeSLIR=$removeSLIR
export vmware35=$vmware35
export vmware40=$vmware40
export startup35=$startup35
export startup40=$startup40
./RunRPM_vmware.sh
